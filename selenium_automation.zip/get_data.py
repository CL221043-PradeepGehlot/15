from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
import time

def get_google_search_titles(query):
    driver = webdriver.Chrome()
    driver.get("https://www.google.com")

    search_box = driver.find_element(By.NAME, "q")
    search_box.send_keys(query)
    search_box.send_keys(Keys.RETURN)

    time.sleep(3)

    titles = driver.find_elements(By.TAG_NAME, "h3")
    print(f"Search Results for: {query}\n")
    for idx, title in enumerate(titles[:10], 1):
        print(f"{idx}. {title.text}")

    driver.quit()

if __name__ == "__main__":
    get_google_search_titles("latest AI tools 2025")
