# Selenium Automation Project

## Description
This script uses Selenium to automate a Google search and extract the top 10 result titles.

## Requirements
- Python
- Selenium
- ChromeDriver

## How to Run
1. Install Selenium:
   pip install selenium

2. Make sure ChromeDriver is in your PATH or same folder.

3. Run the script:
   python get_data.py
